﻿using ProyectoAnalizadorLéxico.logica;
using System;

using System.Windows.Forms;

namespace ProyectoAnalizadorLéxico
{
    public partial class FormPrincipal : Form
    {
        
        private AnalizadorLexico analizadorLexico;

        public FormPrincipal()
        {
            InitializeComponent();
            analizadorLexico = new AnalizadorLexico();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            if (dvgTokens != null) dvgTokens.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            if (dgvErrores != null) dgvErrores.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnAnalizar_Click(object sender, EventArgs e)
        {
            string codigoFuente =txtCodigoFuente.Text;

            if(string.IsNullOrWhiteSpace(codigoFuente) )
            {
                MessageBox.Show("por favor, ingresa o carga codigo fuente para analizar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            analizadorLexico.Analizar(codigoFuente);

            var listaTokens = analizadorLexico.ObtenerTokens();
            var listaErrores = analizadorLexico.ObtenerErrores();

            dgvErrores.DataSource = null;
            dgvErrores .DataSource = listaErrores;

            dvgTokens.DataSource = null;
            dvgTokens .DataSource = listaTokens;

            if (listaErrores != null && listaErrores.Count > 0)
            {
                MessageBox.Show($"El análisis finalizó con {listaErrores.Count} error(es) léxico(s).",
                                "Análisis Finalizado",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("El análisis léxico se completó con éxito sin errores.",
                                "Análisis Exitoso",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private void btnCargarArchivo_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
                ofd.Title = "Seleccionar archivo de código fuente";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string contenido = System.IO.File.ReadAllText(ofd.FileName);
                        txtCodigoFuente.Text = contenido;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al leer el archivo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
