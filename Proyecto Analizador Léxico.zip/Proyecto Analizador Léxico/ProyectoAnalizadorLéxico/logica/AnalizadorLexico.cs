﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using ProyectoAnalizadorLéxico.modelos;

namespace ProyectoAnalizadorLéxico.logica
{
    public class AnalizadorLexico
    {
        private List<Token> listaTokens;
        private List<ErrorLexico> listaErrores;

        private TablaDeSimbolos tablaSimbolos;

        public AnalizadorLexico()

        {
            listaErrores = new List<ErrorLexico>();
            listaTokens = new List<Token>();
            tablaSimbolos = new TablaDeSimbolos();
        }

        public void Analizar ( string codigoFuente)
        {
            listaTokens.Clear();
            listaErrores.Clear();

            int linea = 1;
            int columna = 1;
            int i = 0;

            while ( i< codigoFuente.Length)
            {
                char c = codigoFuente[i];

                if ( c == '\n')
                {
                    linea++;
                    columna = 1;
                    i++;
                    continue;
                }

                if (Char.IsWhiteSpace(c))
                {
                    columna++;
                    i++;
                    continue;

                }

                if (char.IsLetter(c))
                {
                    string lexema = "";
                    while (i < codigoFuente.Length && (char.IsLetterOrDigit(codigoFuente[i]) || codigoFuente[i] == '_'))
                    {
                        lexema += codigoFuente[i];
                        columna++;
                        i++;

                    }

                    //listaTokens.Add(new Token(lexema, "Identidicador", linea, columna - lexema.Length));
        
                    string tipo = "TKN_ID";
                    switch (lexema)
                    {
                        // Tipos integrados / primitivos
                        case "bool":
                        case "byte":
                        case "char":
                        case "decimal":
                        case "double":
                        case "float":
                        case "int":
                        case "long":
                        case "object":
                        case "sbyte":
                        case "short":
                        case "string":
                        case "uint":
                        case "ulong":
                        case "ushort":
                        case "void":
                            tipo = "TKN_TYPE_PRIMITIVO"; break;

                        // Declaración de tipos
                        case "class":
                        case "struct":
                        case "interface":
                        case "enum":
                        case "delegate":
                        case "record":
                            tipo = "TKN_TYPE_DECL"; break;

                        // Modificadores de acceso
                        case "public":
                        case "private":
                        case "protected":
                        case "internal":
                        case "file":
                            tipo = "TKN_MOD_ACCESO"; break;

                        // Modificadores de comportamiento
                        case "abstract":
                        case "async":
                        case "const":
                        case "event":
                        case "extern":
                        case "in":
                        case "out":
                        case "override":
                        case "readonly":
                        case "ref":
                        case "sealed":
                        case "static":
                        case "virtual":
                        case "volatile":
                            tipo = "TKN_MOD_COMP"; break;

                        // Sentencias de control y bucles
                        case "break":
                        case "case":
                        case "continue":
                        case "default":
                        case "do":
                        case "else":
                        case "for":
                        case "foreach":
                        case "goto":
                        case "if":
                        case "return":
                        case "switch":
                        case "while":
                            tipo = "TKN_CTRL_BCLS"; break;

                        // Manejo de excepciones
                        case "try":
                        case "catch":
                        case "finally":
                        case "throw":
                            tipo = "TKN_EXCEPT_DECL"; break;

                        // Gestión de memoria y punteros
                        case "fixed":
                        case "stackalloc":
                        case "unsafe":
                            tipo = "TKN_MEM_DECL"; break;

                        // Operadores e Inspección de Tipos
                        case "as":
                        case "await":
                        case "checked":
                        case "unchecked":
                        case "is":
                        case "nameof":
                        case "typeof":
                        case "new":
                        case "sizeof":
                            tipo = "TKN_KEYWORD_OP"; break;

                        // Ámbitos y referencias de instancia
                        case "base":
                        case "this":
                        case "namespace":
                        case "using":
                        case "lock":
                            tipo = "TKN_SCOPE_REF"; break;

                        // Literales booleanos y nulos
                        case "false":
                        case "true":
                        case "null":
                            tipo = "TKN_LITERAL_CONST"; break;
                    }

                    listaTokens.Add(new Token(lexema, tipo, linea, columna - lexema.Length));

                    if (tipo == "TKN_ID")
                    {
                        Simbolo nuevoSimbolo = new Simbolo { Name = lexema, Line = linea, Column = columna - lexema.Length };
                        tablaSimbolos.AgregarSimbolo(nuevoSimbolo);
                    }

                }
                else if (char.IsDigit(c))
                {
                    string lexema = "";
                    bool tienePunto = false;

                    while (i < codigoFuente.Length && (char.IsDigit(codigoFuente[i]) || codigoFuente[i] == '.'))
                    {
                        if (codigoFuente[i] == '.')
                        {
                            if (tienePunto) break;
                            tienePunto = true;
                        }

                        lexema += codigoFuente[i];
                        columna++;
                        i++;
                    }
                    string tipoToken = tienePunto ? "TKN_NUM_DEC" : "TKN_NUM_INT";
                    listaTokens.Add(new Token(lexema, tipoToken, linea, columna - lexema.Length));
                    //listaTokens.Add(new Token(lexema, "NumeroEntero", linea, columna - lexema.Length));
                }
                else if (c == '"')
                {
                    string lexema = c.ToString();
                    int columnaInicio = columna;
                    columna++;
                    i++;

                    while (i < codigoFuente.Length && codigoFuente[i] != '"' && codigoFuente[i] != '\n')
                    {
                        lexema += codigoFuente[i];
                        columna++;
                        i++;
                    }

                    if (i < codigoFuente.Length && codigoFuente[i] == '"')
                    {
                        lexema += codigoFuente[i];
                        columna++;
                        i++;
                        listaTokens.Add(new Token(lexema, "TKN_CADENA_TEXTO", linea, columnaInicio));
                    }
                    else
                    {
                        listaErrores.Add(new ErrorLexico(lexema, linea, columnaInicio, "Cadena de texto sin cerrar"));
                    }
                }
                else if (c == '\'')
                {
                    string lexema = c.ToString();
                    int columnaInicio = columna;
                    columna++;
                    i++;

                    while (i < codigoFuente.Length && codigoFuente[i] != '\'' && codigoFuente[i] != '\n')
                    {
                        lexema += codigoFuente[i];
                        columna++;
                        i++;
                    }

                    if (i < codigoFuente.Length && codigoFuente[i] == '\'')
                    {
                        lexema += codigoFuente[i];
                        columna++;
                        i++;
                        listaTokens.Add(new Token(lexema, "TKN_CARACTER", linea, columnaInicio));
                    }
                    else
                    {
                        listaErrores.Add(new ErrorLexico(lexema, linea, columnaInicio, "Caracter literal sin cerrar"));
                    }
                }

                else if (c == '=' || c == '+' || c == '-' || c == ';' || c == '*' || c == '/' || c == '!' || c == '&' || c == '|' || c == '.' || c == ',') 
                {
                    string lexema = c.ToString();
                    int columnaInicio = columna; 

                    if (i + 1 < codigoFuente.Length)
                    {
                        char siguiente = codigoFuente[i + 1];
                        if ((c == '=' && siguiente == '=') ||
                            (c == '!' && siguiente == '=') ||
                            (c == '&' && siguiente == '&') ||
                            (c == '|' && siguiente == '|'))
                        {
                            lexema += siguiente;
                            columna++;
                            i++;
                        }
                    }

                    listaTokens.Add(new Token(lexema, "TKN_OP_PUNCT", linea, columnaInicio));
                    columna++;
                    i++;
                    //listaTokens.Add(new Token(c.ToString(), "Operador/Puntuacion", linea, columna));

                }

                else
                {
                    listaErrores.Add(new ErrorLexico(c.ToString(), linea, columna, "caracter no reconocido por el lenguaje"));
                    columna++;
                    i++;
                }
            }
        }

        public List<Token> ObtenerTokens() => listaTokens;
        public List<ErrorLexico>ObtenerErrores() => listaErrores;
    }
}
