﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAnalizadorLéxico.modelos
{
    public class Token
    {
        public string Lexema {  get; set; }
        public string TipoToken { get; set; }
        
        public int Linea { get; set; }
        public int columna { get; set; }

    }

}
