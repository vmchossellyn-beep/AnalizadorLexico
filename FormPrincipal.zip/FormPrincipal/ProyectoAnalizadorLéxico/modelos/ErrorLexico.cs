﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAnalizadorLéxico.modelos
{
    public class ErrorLexico
    {
        public string Lexema { get; set;  }
        public string Descripcion { get; set; }
        public int Linea { get; set; }
        public int Columna { get; set; }

    }
}
