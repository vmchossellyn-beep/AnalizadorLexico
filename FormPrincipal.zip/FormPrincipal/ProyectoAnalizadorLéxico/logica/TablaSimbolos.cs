﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProyectoAnalizadorLéxico.modelos;

namespace ProyectoAnalizadorLéxico.logica
{
    public class TablaDeSimbolos
    {
        private Dictionary<string, Simbolo> sombolos = new Dictionary<string, Simbolo>();

        public bool AgregarSimbolo(Simbolo s)
        {
            return false;
        }
        public Simbolo BuscarSimbolo(string nombre)
        {
            return null;
        }
    }
}
