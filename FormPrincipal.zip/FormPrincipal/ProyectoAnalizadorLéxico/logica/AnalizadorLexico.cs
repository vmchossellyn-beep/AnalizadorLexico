﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using ProyectoAnalizadorLéxico.modelos;

namespace ProyectoAnalizadorLéxico.logica
{
    public class AnalizadorLexico
    {
        private AutomataAFD automata;
        private TablaDeSimbolos tablaSimbolos;
        private List<Token> listaTokens;
        private List<ErrorLexico> listaErrores;

        public AnalizadorLexico()
        {
            automata = new AutomataAFD();
            tablaSimbolos = new TablaDeSimbolos();
            listaTokens = new List<Token>();
            listaErrores = new List<ErrorLexico>();
        }


        public void Analizar(string codigoFuente)
        {
            listaTokens = new List<Token>();
            listaErrores = new List<ErrorLexico>();

            if (string.IsNullOrWhiteSpace(codigoFuente))
                return;

            int lineaActual = 1;
            int columnaActual = 1;

            for ( int i = 0;i< codigoFuente.Length;i++ )
            {
                char c = codigoFuente[i];

                if (c == '\n')
                {
                    lineaActual++;
                    columnaActual = 1;
                    continue;
                }
                else if (c == '\r' || char.IsWhiteSpace(c))
                {
                    columnaActual++;
                    continue;
                }

                Token tokenProcesado = automata.ProcesarCaracter(c);

                if(tokenProcesado != null)
                {
                    tokenProcesado.Linea = lineaActual;
                    tokenProcesado.columna = columnaActual;

                    listaTokens.Add(tokenProcesado);

                    if (tokenProcesado.TipoToken == "Identificador")
                    {
                        Simbolo nuevoSimbolo = new Simbolo
                        {
                            Name = tokenProcesado.Lexema,
                            SymbolKind = "Variable",
                            DataType = "Desconocido",
                            Line = lineaActual,
                            Column = columnaActual,
                        };
                        tablaSimbolos.AgregarSimbolo(nuevoSimbolo);
                    }
                }
                else
                {
                    if (!automata.EsEstadoAceptacion())
                    {
                        ErrorLexico error = new ErrorLexico
                        {
                            Lexema = c.ToString(),
                            Descripcion = "Carácter no reconocido o fuera de lenguaje.",
                            Linea = lineaActual,
                            Columna = columnaActual,
                        };
                        listaErrores.Add(error);
                    }
                }
                columnaActual++;
            }
        }
        public List<Token> ObtenerTokens()
        {
            return listaTokens;
        }
        public List<ErrorLexico> ObtenerErrores()
        {
            return listaErrores;
        }
            

    }
}
