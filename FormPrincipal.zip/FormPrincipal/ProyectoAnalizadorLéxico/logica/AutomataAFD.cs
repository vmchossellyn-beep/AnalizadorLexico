﻿using ProyectoAnalizadorLéxico.modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAnalizadorLéxico.logica
{
    public class AutomataAFD
    {
        private int estadoActual;

        public Token ProcesarCaracter(Char c)
        {
            return null;

        }
        public bool EsEstadoAceptacion()
        {
            return false;
        }
    }
}
